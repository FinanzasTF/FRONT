import { Component } from '@angular/core';

@Component({
  selector: 'app-interes',
  templateUrl: './interes.component.html',
  styleUrls: ['./interes.component.css']
})
export class InteresComponent {
  calendario: boolean = false;

}
