import { Component } from '@angular/core';

@Component({
  selector: 'app-vivenda',
  templateUrl: './vivenda.component.html',
  styleUrls: ['./vivenda.component.css']
})
export class VivendaComponent {
  calendario: boolean = false;

}
