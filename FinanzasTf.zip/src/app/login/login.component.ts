import { Component, Inject } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  name: string = '';
  password: string = '';

  // constructor(@Inject(UserService) private userService: UserService) { }
  constructor(private userService: UserService, private router: Router) { }

  login() {
    // Lógica para iniciar sesión
    this.userService.login(this.name, this.password).subscribe(
      (response) => {
        // Validar la respuesta para determinar si el inicio de sesión fue exitoso
        if (response.success) {
          // Lógica de manejo de inicio de sesión exitoso
          console.log('Inicio de sesión exitoso');
        } else {
          // Lógica de manejo de inicio de sesión fallido
          console.log('Inicio de sesión fallido: Usuario no encontrado');
        }
      },
      (error) => {
        // Lógica de manejo de error de inicio de sesión
        console.error(error);
      }
    );
    this.router.navigate(['/']);
  }

  forgotPassword() {
    // Lógica para el restablecimiento de contraseña
    // Puedes implementar aquí la lógica necesaria para enviar un correo electrónico con instrucciones de restablecimiento de contraseña o cualquier otra acción relacionada con el olvido de contraseña.
    console.log('Se ha solicitado el restablecimiento de contraseña.');
  }
}
